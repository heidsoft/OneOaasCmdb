-- MySQL dump 10.13  Distrib 5.7.16, for Linux (x86_64)
--
-- Host: localhost    Database: community_edition
-- ------------------------------------------------------
-- Server version	5.7.16-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `access_key`
--

DROP TABLE IF EXISTS `access_key`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `access_key` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL,
  `access_key_id` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `access_key_secret` varchar(512) COLLATE utf8_bin DEFAULT NULL,
  `is_disable` int(11) DEFAULT NULL,
  `is_delete` int(11) DEFAULT NULL,
  `expire_time` bigint(20) NOT NULL DEFAULT '0',
  `create_time` datetime NOT NULL,
  `access_key_desc` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `access_key_name` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `access_key_type` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `access_key`
--

LOCK TABLES `access_key` WRITE;
/*!40000 ALTER TABLE `access_key` DISABLE KEYS */;
INSERT INTO `access_key` VALUES (1,1,'e6a3ee8552021a26009d2e5cce573e12','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhZG1pbiI6dHJ1ZSwiZXhwIjoxNDk2MjgwNDM2LCJpYXQiOjE0OTM2ODg0MzYsInR5cGUiOiJzZWxmIiwidXNlcm5hbWUiOiJhZG1pbiJ9.yanrhLrDV6lYHDcRwZxeXVDSEMu9rlnvwpwl-lHQ910',1,0,1496280436,'2017-05-02 09:27:16','system auto generate','frontend','self');
/*!40000 ALTER TABLE `access_key` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agreement`
--

DROP TABLE IF EXISTS `agreement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement` (
  `agreementid` bigint(20) NOT NULL AUTO_INCREMENT,
  `agreement_name` varchar(100) NOT NULL DEFAULT '',
  `agreement_no` varchar(100) NOT NULL DEFAULT '',
  `agreement_price` bigint(20) DEFAULT NULL,
  `agreement_sign_date` datetime DEFAULT NULL,
  `agreement_start_date` datetime DEFAULT NULL,
  `agreement_stop_date` datetime DEFAULT NULL,
  `agreement_signer` varchar(100) DEFAULT NULL,
  `agreement_path` varchar(100) DEFAULT NULL,
  `comment` varchar(200) DEFAULT NULL,
  `supplier_id` bigint(20) NOT NULL,
  `state_id` bigint(20) NOT NULL,
  `enable` tinyint(1) DEFAULT NULL,
  `createtime` datetime NOT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `updateby` varchar(100) DEFAULT NULL,
  `updatetime` datetime NOT NULL,
  PRIMARY KEY (`agreementid`),
  UNIQUE KEY `agreement_name` (`agreement_name`),
  UNIQUE KEY `agreement_no` (`agreement_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agreement`
--

LOCK TABLES `agreement` WRITE;
/*!40000 ALTER TABLE `agreement` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agreement_state`
--

DROP TABLE IF EXISTS `agreement_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_state` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `state` varchar(255) DEFAULT NULL,
  `enable` tinyint(1) DEFAULT NULL,
  `createtime` datetime NOT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `updateby` varchar(100) DEFAULT NULL,
  `updatetime` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agreement_state`
--

LOCK TABLES `agreement_state` WRITE;
/*!40000 ALTER TABLE `agreement_state` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app`
--

DROP TABLE IF EXISTS `app`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `app` (
  `appid` bigint(20) NOT NULL AUTO_INCREMENT,
  `app_name` varchar(255) DEFAULT NULL,
  `app_parent_id` bigint(20) DEFAULT NULL,
  `teamown` varchar(256) DEFAULT NULL,
  `devown` varchar(256) DEFAULT NULL,
  `opsown` varchar(256) DEFAULT NULL,
  `comment` varchar(256) DEFAULT NULL,
  `level_id` bigint(20) NOT NULL,
  `enable` tinyint(1) DEFAULT NULL,
  `createtime` datetime NOT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `updateby` varchar(100) DEFAULT NULL,
  `updatetime` datetime NOT NULL,
  `app_code` varchar(255) DEFAULT NULL,
  `app_own` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`appid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app`
--

LOCK TABLES `app` WRITE;
/*!40000 ALTER TABLE `app` DISABLE KEYS */;
/*!40000 ALTER TABLE `app` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_level`
--

DROP TABLE IF EXISTS `app_level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `app_level` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `enable` tinyint(1) DEFAULT NULL,
  `createtime` datetime NOT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `updateby` varchar(100) DEFAULT NULL,
  `updatetime` datetime NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_level`
--

LOCK TABLES `app_level` WRITE;
/*!40000 ALTER TABLE `app_level` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_level` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `asserts`
--

DROP TABLE IF EXISTS `asserts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `asserts` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL DEFAULT '',
  `description` varchar(60) NOT NULL DEFAULT '',
  `inherits` tinyint(1) NOT NULL DEFAULT '0',
  `superclass` tinyint(1) NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `enable` tinyint(1) DEFAULT NULL,
  `createtime` datetime NOT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `updateby` varchar(100) DEFAULT NULL,
  `updatetime` datetime NOT NULL,
  `icon` varchar(60) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asserts`
--

LOCK TABLES `asserts` WRITE;
/*!40000 ALTER TABLE `asserts` DISABLE KEYS */;
INSERT INTO `asserts` VALUES (1,'datacenter','数据中心资源',0,0,0,0,'2017-03-29 10:03:03',NULL,NULL,'2017-03-29 10:03:03','icon-dc'),(3,'business','业务资源',0,0,0,0,'2017-03-29 10:03:03',NULL,NULL,'2017-03-29 10:03:03','icon-bs-rs'),(4,'supplier','供应商资源',0,0,0,0,'2017-03-29 10:03:03',NULL,NULL,'2017-03-29 10:03:03','icon-supplier');
/*!40000 ALTER TABLE `asserts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `asserts_instance`
--

DROP TABLE IF EXISTS `asserts_instance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `asserts_instance` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) COLLATE utf8_bin NOT NULL DEFAULT '',
  `description` varchar(60) COLLATE utf8_bin NOT NULL DEFAULT '',
  `inherits` tinyint(1) NOT NULL DEFAULT '1',
  `superclass` tinyint(1) NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `asserts_id` bigint(20) NOT NULL,
  `enable` tinyint(1) DEFAULT NULL,
  `createtime` datetime NOT NULL,
  `createby` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `updateby` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `updatetime` datetime NOT NULL,
  `icon` varchar(60) COLLATE utf8_bin NOT NULL DEFAULT '',
  `number` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asserts_instance`
--

LOCK TABLES `asserts_instance` WRITE;
/*!40000 ALTER TABLE `asserts_instance` DISABLE KEYS */;
INSERT INTO `asserts_instance` VALUES (1,'datacenter','数据中心',1,0,1,1,1,'2017-05-09 16:57:52','','admin','2017-05-09 16:57:52','icon-index-dc',0),(2,'room','机房',1,0,1,1,1,'2017-05-09 16:57:52','','admin','2017-05-09 16:57:52','icon-index-room',0),(3,'rack','机柜',1,0,1,1,0,'2017-05-09 16:57:52','','admin','2017-05-09 16:57:52','icon-index-rack',0),(4,'bandwidth','带宽',1,0,1,1,0,'2017-05-09 16:57:52','','admin','2017-05-09 16:57:52','icon-index-bandwidth',0),(5,'hardware','硬件',1,0,1,1,0,'2017-05-09 16:57:53','','admin','2017-05-09 16:57:53','icon-index-hardware',0),(6,'server','服务器',1,0,1,1,0,'2017-05-09 16:57:53','','admin','2017-05-09 16:57:53','icon-index-server',0),(7,'ip','IP',1,0,1,2,0,'2017-02-20 18:20:44','','admin','2017-02-20 18:20:44','icon-index-ip',5),(8,'domain','域名',1,0,1,2,0,'2017-05-09 16:57:53','','admin','2017-05-09 16:57:53','icon-index-domain',0),(9,'app','业务模块',1,0,1,3,0,'2017-05-09 16:57:54','','admin','2017-05-09 16:57:54','icon-index-app',0),(10,'vcenter','Vcenter',1,0,1,5,0,'2017-05-09 13:00:41','','admin','2017-05-09 13:00:41','icon-index-vcenter',0),(11,'aliyun','阿里云',1,0,1,5,0,'2017-05-09 16:57:54','','admin','2017-05-09 16:57:54','icon-index-aliyun',0),(12,'aws','AWS',1,0,1,5,0,'2017-05-09 16:57:55','','admin','2017-05-09 16:57:55','icon-index-aws',0),(13,'supplier','供应商',1,0,1,4,0,'2017-05-09 16:57:55','','admin','2017-05-09 16:57:55','icon-index-supplier',0),(14,'agreement','合同',1,0,1,100,0,'2017-05-09 16:57:55','','admin','2017-05-09 16:57:55','icon-supplier',0);
/*!40000 ALTER TABLE `asserts_instance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cpu`
--

DROP TABLE IF EXISTS `cpu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cpu` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `enable` tinyint(1) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `updateby` varchar(100) DEFAULT NULL,
  `updatetime` datetime DEFAULT NULL,
  `server_id` bigint(20) DEFAULT NULL,
  `cpu` int(11) DEFAULT NULL,
  `vendor_id` varchar(255) DEFAULT NULL,
  `family` varchar(255) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `stepping` int(11) DEFAULT NULL,
  `physical_id` varchar(255) DEFAULT NULL,
  `core_id` varchar(255) DEFAULT NULL,
  `cores` int(11) DEFAULT NULL,
  `model_name` varchar(255) DEFAULT NULL,
  `mhz` double DEFAULT NULL,
  `cache_size` int(11) DEFAULT NULL,
  `flags` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cpu`
--

LOCK TABLES `cpu` WRITE;
/*!40000 ALTER TABLE `cpu` DISABLE KEYS */;
INSERT INTO `cpu` VALUES (5,'',1,'2017-04-11 13:39:28','','','2017-04-11 13:39:28',1,0,'GenuineIntel','6','61',4,'','',2,'Intel(R) Core(TM) i5-5250U CPU @ 1.60GHz',1600,256,'syscall,xd,1gbpage,em64t,lahf,lzcnt,prefetchw,rdtscp,tsci,smep,erms,rdwrfsgs,tsc_thread_offset,bmi1,avx2,bmi2,invpcid,smap,rdseed,adx,ipt,fpu_csds,fpu,vme,de,pse,tsc,msr,pae,mce,cx8,apic,sep,mtrr,pge,mca,cmov,pat,pse36,clfsh,ds,acpi,mmx,fxsr,sse,sse2,ss,htt,tm,pbe,sse3,pclmulqdq,dtes64,mon,dscpl,vmx,est,tm2,ssse3,fma,cx16,tpr,pdcm,sse4.1,sse4.2,x2apic,movbe,popcnt,aes,pcid,xsave,osxsave,seglim64,tsctmr,avx1.0,rdrand,f16c'),(6,'',1,'2017-04-14 11:05:38','','','2017-04-14 11:05:38',2,0,'GenuineIntel','6','45',7,'0','0',1,'Intel(R) Xeon(R) CPU E5-2620 0 @ 2.00GHz',2000,15360,'fpu,vme,de,pse,tsc,msr,pae,mce,cx8,apic,sep,mtrr,pge,mca,cmov,pat,pse36,clflush,dts,mmx,fxsr,sse,sse2,ss,syscall,nx,rdtscp,lm,constant_tsc,up,arch_perfmon,pebs,bts,xtopology,tsc_reliable,nonstop_tsc,aperfmperf,unfair_spinlock,pni,pclmulqdq,ssse3,cx16,pcid,sse4_1,sse4_2,x2apic,popcnt,tsc_deadline_timer,aes,xsave,avx,hypervisor,lahf_lm,ida,arat,pln,pts,dts');
/*!40000 ALTER TABLE `cpu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datacenter`
--

DROP TABLE IF EXISTS `datacenter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datacenter` (
  `dcid` bigint(20) NOT NULL AUTO_INCREMENT,
  `dcname` varchar(255) NOT NULL DEFAULT '',
  `dcprovince` varchar(255) DEFAULT NULL,
  `dccity` varchar(255) DEFAULT NULL,
  `dccounty` varchar(255) DEFAULT NULL,
  `dcaddress` varchar(255) DEFAULT NULL,
  `dcgeo` varchar(255) DEFAULT NULL,
  `comment` varchar(512) DEFAULT NULL,
  `region_id` bigint(20) NOT NULL,
  `state_id` bigint(20) NOT NULL,
  `supplier_id` bigint(20) DEFAULT NULL,
  `enable` tinyint(1) DEFAULT NULL,
  `createtime` datetime NOT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `updateby` varchar(100) DEFAULT NULL,
  `updatetime` datetime NOT NULL,
  PRIMARY KEY (`dcid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datacenter`
--

LOCK TABLES `datacenter` WRITE;
/*!40000 ALTER TABLE `datacenter` DISABLE KEYS */;
/*!40000 ALTER TABLE `datacenter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datacenter_region`
--

DROP TABLE IF EXISTS `datacenter_region`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datacenter_region` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `region_name` varchar(255) DEFAULT NULL,
  `enable` tinyint(1) DEFAULT NULL,
  `createtime` datetime NOT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `updateby` varchar(100) DEFAULT NULL,
  `updatetime` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datacenter_region`
--

LOCK TABLES `datacenter_region` WRITE;
/*!40000 ALTER TABLE `datacenter_region` DISABLE KEYS */;
/*!40000 ALTER TABLE `datacenter_region` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datacenter_state`
--

DROP TABLE IF EXISTS `datacenter_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datacenter_state` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `state` varchar(255) DEFAULT NULL,
  `enable` tinyint(1) DEFAULT NULL,
  `createtime` datetime NOT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `updateby` varchar(100) DEFAULT NULL,
  `updatetime` datetime NOT NULL,
  `color` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datacenter_state`
--

LOCK TABLES `datacenter_state` WRITE;
/*!40000 ALTER TABLE `datacenter_state` DISABLE KEYS */;
/*!40000 ALTER TABLE `datacenter_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `docmanage`
--

DROP TABLE IF EXISTS `docmanage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `docmanage` (
  `docmanageid` bigint(20) NOT NULL AUTO_INCREMENT,
  `docmanagename` varchar(255) DEFAULT NULL,
  `status` bigint(20) DEFAULT NULL,
  `docmanageno` varchar(256) DEFAULT NULL,
  `docpath` varchar(256) DEFAULT NULL,
  `doctype` varchar(256) DEFAULT NULL,
  `comment` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`docmanageid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `docmanage`
--

LOCK TABLES `docmanage` WRITE;
/*!40000 ALTER TABLE `docmanage` DISABLE KEYS */;
/*!40000 ALTER TABLE `docmanage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `harddisk`
--

DROP TABLE IF EXISTS `harddisk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `harddisk` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `enable` tinyint(1) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `updateby` varchar(100) DEFAULT NULL,
  `updatetime` datetime DEFAULT NULL,
  `server_id` bigint(20) DEFAULT NULL,
  `device` varchar(64) NOT NULL DEFAULT '',
  `mountpoint` varchar(64) NOT NULL DEFAULT '',
  `fstype` varchar(64) NOT NULL DEFAULT '',
  `opts` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `harddisk`
--

LOCK TABLES `harddisk` WRITE;
/*!40000 ALTER TABLE `harddisk` DISABLE KEYS */;
INSERT INTO `harddisk` VALUES (1,0,NULL,'','','2017-04-11 16:24:41',1,'/dev/disk1','/','hfs','rw,multilabel'),(2,0,NULL,'','','2017-04-11 16:24:41',1,'devfs','/dev','devfs','rw,suiddir,multilabel'),(3,0,NULL,'','','2017-04-11 16:24:41',1,'map -hosts','/net','autofs','rw,nosuid,suiddir,nosymfollow,multilabel'),(4,0,NULL,'','','2017-04-11 16:24:41',1,'map auto_home','/home','autofs','rw,suiddir,nosymfollow,multilabel'),(5,0,'2017-04-11 16:58:51','','','2017-04-11 16:58:51',1,'/dev/mapper/vg_localhost-lv_root','/','ext4','rw'),(6,0,'2017-04-11 16:58:51','','','2017-04-11 16:58:51',1,'proc','/proc','proc','rw'),(7,0,'2017-04-11 16:58:51','','','2017-04-11 16:58:51',1,'sysfs','/sys','sysfs','rw'),(8,0,'2017-04-11 16:58:52','','','2017-04-11 16:58:52',1,'devpts','/dev/pts','devpts','rw,gid=5,mode=620'),(9,0,'2017-04-11 16:58:52','','','2017-04-11 16:58:52',1,'tmpfs','/dev/shm','tmpfs','rw'),(10,0,'2017-04-11 16:58:52','','','2017-04-11 16:58:52',1,'/dev/sda1','/boot','ext4','rw'),(11,0,'2017-04-11 16:58:52','','','2017-04-11 16:58:52',1,'/dev/mapper/vg_localhost-lv_home','/home','ext4','rw'),(12,0,'2017-04-11 16:58:52','','','2017-04-11 16:58:52',1,'none','/proc/sys/fs/binfmt_misc','binfmt_misc','rw'),(13,0,'2017-04-11 16:58:52','','','2017-04-11 16:58:52',1,'vmware-vmblock','/var/run/vmblock-fuse','fuse.vmware-vmblock','rw,nosuid,nodev,default_permissions,allow_other'),(14,0,'2017-04-11 16:58:52','','','2017-04-11 16:58:52',1,'gvfs-fuse-daemon','/root/.gvfs','fuse.gvfs-fuse-daemon','rw,nosuid,nodev'),(15,0,NULL,'','','2017-04-14 11:05:29',2,'/dev/sda3','/','ext4','rw'),(16,0,NULL,'','','2017-04-14 11:05:29',2,'proc','/proc','proc','rw'),(17,0,NULL,'','','2017-04-14 11:05:29',2,'sysfs','/sys','sysfs','rw'),(18,0,NULL,'','','2017-04-14 11:05:30',2,'devpts','/dev/pts','devpts','rw,gid=5,mode=620'),(19,0,NULL,'','','2017-04-14 11:05:30',2,'tmpfs','/dev/shm','tmpfs','rw,rootcontext=\"system_u:object_r:tmpfs_t:s0\"'),(20,0,NULL,'','','2017-04-14 11:05:30',2,'/dev/sda1','/boot','ext4','rw'),(21,0,NULL,'','','2017-04-14 11:05:30',2,'none','/proc/sys/fs/binfmt_misc','binfmt_misc','rw');
/*!40000 ALTER TABLE `harddisk` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hardware`
--

DROP TABLE IF EXISTS `hardware`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hardware` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `online` bigint(20) DEFAULT NULL,
  `hardware_sn` varchar(256) DEFAULT NULL,
  `hardware_name` varchar(255) DEFAULT NULL,
  `manager_ip` varchar(255) DEFAULT NULL,
  `comment` varchar(512) DEFAULT NULL,
  `rack_id` bigint(20) DEFAULT NULL,
  `type_id` bigint(20) NOT NULL,
  `state_id` bigint(20) NOT NULL,
  `manage_ip` varchar(255) DEFAULT NULL,
  `enable` tinyint(1) DEFAULT NULL,
  `createtime` datetime NOT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `updateby` varchar(100) DEFAULT NULL,
  `updatetime` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hardware`
--

LOCK TABLES `hardware` WRITE;
/*!40000 ALTER TABLE `hardware` DISABLE KEYS */;
/*!40000 ALTER TABLE `hardware` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hardware_state`
--

DROP TABLE IF EXISTS `hardware_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hardware_state` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `state` varchar(255) NOT NULL DEFAULT '',
  `enable` tinyint(1) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `updateby` varchar(100) DEFAULT NULL,
  `updatetime` datetime DEFAULT NULL,
  `color` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hardware_state`
--

LOCK TABLES `hardware_state` WRITE;
/*!40000 ALTER TABLE `hardware_state` DISABLE KEYS */;
/*!40000 ALTER TABLE `hardware_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hardware_type`
--

DROP TABLE IF EXISTS `hardware_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hardware_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `enable` tinyint(1) DEFAULT NULL,
  `createtime` datetime NOT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `updateby` varchar(100) DEFAULT NULL,
  `updatetime` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hardware_type`
--

LOCK TABLES `hardware_type` WRITE;
/*!40000 ALTER TABLE `hardware_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `hardware_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `host`
--

DROP TABLE IF EXISTS `host`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `host` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `enable` tinyint(1) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `updateby` varchar(100) DEFAULT NULL,
  `updatetime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `host`
--

LOCK TABLES `host` WRITE;
/*!40000 ALTER TABLE `host` DISABLE KEYS */;
INSERT INTO `host` VALUES (1,'esxi5.5',0,'2017-04-01 12:33:41','','','2017-04-01 12:33:41'),(2,'centos6.5',0,'2017-04-11 13:33:01','','','2017-04-11 13:33:01');
/*!40000 ALTER TABLE `host` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `internet_service_provider`
--

DROP TABLE IF EXISTS `internet_service_provider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `internet_service_provider` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `enable` tinyint(1) DEFAULT NULL,
  `createtime` datetime NOT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `updateby` varchar(100) DEFAULT NULL,
  `updatetime` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `internet_service_provider`
--

LOCK TABLES `internet_service_provider` WRITE;
/*!40000 ALTER TABLE `internet_service_provider` DISABLE KEYS */;
/*!40000 ALTER TABLE `internet_service_provider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ip_address`
--

DROP TABLE IF EXISTS `ip_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ip_address` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(20) DEFAULT NULL,
  `is_gateway` int(1) DEFAULT NULL,
  `dns_name` varchar(128) DEFAULT NULL,
  `state` int(11) DEFAULT NULL,
  `port` varchar(128) DEFAULT NULL,
  `owner` varchar(128) DEFAULT NULL,
  `description` varchar(512) DEFAULT NULL,
  `allow_modify` int(11) DEFAULT NULL,
  `device_type` varchar(128) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `app_id` bigint(20) DEFAULT NULL,
  `ip_subnet` bigint(20) DEFAULT NULL,
  `host_id` bigint(20) DEFAULT NULL,
  `room_id` bigint(20) DEFAULT NULL,
  `enable` tinyint(1) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `updateby` varchar(100) DEFAULT NULL,
  `updatetime` datetime DEFAULT NULL,
  `hostname_prefix` varchar(255) DEFAULT NULL,
  `hostname` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1271 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ip_address`
--

LOCK TABLES `ip_address` WRITE;
/*!40000 ALTER TABLE `ip_address` DISABLE KEYS */;
/*!40000 ALTER TABLE `ip_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ip_subnet`
--

DROP TABLE IF EXISTS `ip_subnet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ip_subnet` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `subnet_address` varchar(255) DEFAULT NULL,
  `subnet_description` varchar(512) DEFAULT NULL,
  `mask` varchar(3) DEFAULT NULL,
  `vlan` varchar(50) DEFAULT NULL,
  `allow_allocation` int(11) DEFAULT NULL,
  `check_ip_state` int(11) DEFAULT NULL,
  `enable` tinyint(1) DEFAULT NULL,
  `createtime` datetime NOT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `updateby` varchar(100) DEFAULT NULL,
  `updatetime` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ip_subnet`
--

LOCK TABLES `ip_subnet` WRITE;
/*!40000 ALTER TABLE `ip_subnet` DISABLE KEYS */;
/*!40000 ALTER TABLE `ip_subnet` ENABLE KEYS */;
UNLOCK TABLES;


--
-- Table structure for table `manufacturer`
--

DROP TABLE IF EXISTS `manufacturer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `manufacturer` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `manufacturer` varchar(255) DEFAULT NULL,
  `email` varchar(11) DEFAULT NULL,
  `telphone` varchar(11) DEFAULT NULL,
  `comment` varchar(512) DEFAULT NULL,
  `enable` tinyint(1) DEFAULT NULL,
  `createtime` datetime NOT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `updateby` varchar(100) DEFAULT NULL,
  `updatetime` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manufacturer`
--

LOCK TABLES `manufacturer` WRITE;
/*!40000 ALTER TABLE `manufacturer` DISABLE KEYS */;
/*!40000 ALTER TABLE `manufacturer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `memory`
--

DROP TABLE IF EXISTS `memory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `memory` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `enable` tinyint(1) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `updateby` varchar(100) DEFAULT NULL,
  `updatetime` datetime DEFAULT NULL,
  `server_id` bigint(20) DEFAULT NULL,
  `virtual_total` bigint(20) unsigned NOT NULL DEFAULT '0',
  `virtual_available` bigint(20) unsigned NOT NULL DEFAULT '0',
  `virtual_used` bigint(20) unsigned NOT NULL DEFAULT '0',
  `virtual_used_percent` double NOT NULL DEFAULT '0',
  `virtual_free` bigint(20) unsigned NOT NULL DEFAULT '0',
  `swap_total` bigint(20) unsigned NOT NULL DEFAULT '0',
  `swap_used` bigint(20) unsigned NOT NULL DEFAULT '0',
  `swap_used_percent` double NOT NULL DEFAULT '0',
  `swap_free` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `memory`
--

LOCK TABLES `memory` WRITE;
/*!40000 ALTER TABLE `memory` DISABLE KEYS */;
INSERT INTO `memory` VALUES (26,0,NULL,'','','2017-04-11 15:05:39',1,8589934592,2889912320,5700022272,66.35699272155762,665546752,1073741824,200802304,18.701171875,872939520);
/*!40000 ALTER TABLE `memory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu` (
  `menuId` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `display_name` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(50) DEFAULT NULL,
  `parentId` bigint(20) DEFAULT NULL,
  `enable` tinyint(1) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  `createby` varchar(100) DEFAULT '',
  `updateby` varchar(100) DEFAULT '',
  `updatetime` datetime DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `level` bigint(5) DEFAULT NULL,
  `logo` varchar(20) DEFAULT NULL,
  `class` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`menuId`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu`
--

LOCK TABLES `menu` WRITE;
/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
INSERT INTO `menu` VALUES (2,'root.resource','资源管理','',0,1,NULL,'admin','','2017-01-05 16:10:19',0,1,'fa fa-exchange',''),(3,'root.system','系统管理','',0,1,NULL,'admin','','2017-01-05 16:10:20',0,1,'fa fa-hand-o-right',''),(4,'root.report','资源报表','',0,0,'2016-12-15 19:10:56','admin','admin','2016-12-15 19:10:56',0,1,NULL,NULL),(33,'root.systemuser','用户管理','/systemuser',3,1,NULL,'admin','','2017-01-05 16:10:20',0,2,'',''),(34,'root.systemconfig','系统配置','/systemconfig',3,1,NULL,'admin','','2017-01-05 16:10:20',0,2,'',''),(35,'root.system.users','用户列表','/users',33,1,NULL,'','',NULL,0,3,NULL,NULL),(37,'root.system.menus','菜单管理','/menus',34,0,NULL,'','',NULL,3,3,NULL,NULL),(39,'root.system.logs','日志管理','/logs',34,1,NULL,'','',NULL,3,3,NULL,NULL),(40,'root.system.email','邮件设置','/email',34,0,NULL,'','',NULL,3,3,NULL,NULL),(46,'root.visualization','资源可视化','/resource_view',0,0,NULL,'admin','','2016-11-24 15:31:26',0,1,'fa fa-eye',''),(47,'root.resource_quick','分类查询','/resource_quick',1,1,NULL,'admin','','2016-10-25 23:59:00',0,2,'',''),(48,'root.system.apikey','KEY列表','/apikey',45,1,NULL,'','',NULL,3,3,NULL,NULL),(50,'root.visualization.tree','资源树','/resource_tree',46,1,'2016-09-17 22:24:40','oneoaas','','2016-10-25 23:59:07',0,2,'fa fa-tachometer',''),(51,'root.visualization.topo','拓扑图','/resource_topo',46,1,'2016-09-19 00:25:29','oneoaas','','2016-11-24 15:31:26',0,2,'fa fa-tachometer',''),(52,'root.manageresources.datacenter({assertsId:1})','数据中心资源','/datacenter',2,1,NULL,'','','2017-01-05 16:10:19',0,0,'',''),(53,'root.manageresources.bandwidth({assertsId:2})','IPAM资源','/ipam',2,1,NULL,'','','2017-01-05 16:10:19',0,0,'',''),(54,'root.manageresources.app({assertsId:3})','业务资源','/business',2,1,NULL,'','','2017-01-05 16:10:19',0,0,'',''),(55,'root.manageresources.vcenter({assertsId:4})','虚拟化资源','/virtualization',2,1,NULL,'','','2017-01-05 16:10:19',0,0,'',''),(56,'root.manageresources.aliyun({assertsId:5})','云资源','/cloud',2,1,NULL,'','','2017-01-05 16:10:19',0,0,'',''),(57,'root.manageresources.supplier({assertsId:6})','供应商资源','/supplier',2,1,NULL,'','','2017-01-05 16:10:20',0,0,'',''),(60,'root.report.device','设备性能报表','/device',4,0,'2016-12-15 19:10:56','admin','admin','2016-12-15 19:10:56',0,2,NULL,NULL),(61,'root.report.finance','财务报表','/finance',4,0,'2016-12-15 19:10:56','admin','admin','2016-12-15 19:10:56',0,2,NULL,NULL),(62,'root.report.use','资源报表','/use',4,0,'2016-12-15 19:10:56','admin','admin','2016-12-15 19:10:56',0,2,NULL,NULL),(63,'root.report.devicedetail','设备性能报表详情','/devicedetail',60,0,'2016-12-15 19:10:56','admin','admin','2016-12-15 19:10:56',0,3,NULL,NULL),(64,'root.report.financedetail','财务报表详情','/financedetail',61,0,'2016-12-15 19:10:56','admin','admin','2016-12-15 19:10:56',0,3,NULL,NULL),(65,'root.report.usedetail','资源报表详情','/usedetail',62,1,'2016-12-15 19:10:56','admin','admin','2016-12-15 19:10:56',0,3,NULL,NULL),(66,'root.visualization.rtop','资源拓扑图','/rtop',51,1,'2016-12-15 19:10:56','admin','admin','2016-12-15 19:10:56',0,3,NULL,NULL),(67,'root.visualization.btop','业务拓扑图','/btop',51,1,'2016-12-15 19:10:56','admin','admin','2016-12-15 19:10:56',0,3,NULL,NULL),(68,'root.visualization.rtree','资源树','/rtree',50,1,'2016-12-15 19:10:56','admin','admin','2016-12-15 19:10:56',0,3,NULL,NULL),(69,'root.system.modeling','资产建模','/modeling',34,0,'2016-12-15 19:10:56','admin','admin','2016-12-15 19:10:56',0,3,NULL,NULL);
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_rights`
--

DROP TABLE IF EXISTS `menu_rights`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_rights` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `menu_id` bigint(20) NOT NULL,
  `right_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_rights`
--

LOCK TABLES `menu_rights` WRITE;
/*!40000 ALTER TABLE `menu_rights` DISABLE KEYS */;
/*!40000 ALTER TABLE `menu_rights` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_roles`
--

DROP TABLE IF EXISTS `menu_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_roles` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `menu_id` bigint(20) NOT NULL,
  `role_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=910 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_roles`
--

LOCK TABLES `menu_roles` WRITE;
/*!40000 ALTER TABLE `menu_roles` DISABLE KEYS */;
INSERT INTO `menu_roles` VALUES (367,2,8),(368,52,8),(369,53,8),(370,54,8),(371,55,8),(372,56,8),(373,57,8),(374,3,8),(375,33,8),(376,34,8),(377,45,8),(378,46,8),(379,51,8),(687,2,12),(688,53,12),(689,2,13),(690,52,13),(691,53,13),(692,54,13),(693,55,13),(694,56,13),(695,57,13),(696,46,13),(697,51,13),(847,69,8),(880,35,8),(881,36,8),(882,37,8),(883,38,8),(884,39,8),(885,48,8),(886,4,8),(887,60,8),(888,61,8),(889,62,8),(890,63,8),(891,64,8),(892,65,8),(893,66,8),(894,67,8),(895,68,8),(896,69,8),(897,2,11),(898,52,11),(899,53,11),(900,54,11),(901,55,11),(902,56,11),(903,2,9),(904,52,9),(905,53,9),(906,54,9),(907,55,9),(908,56,9),(909,57,9);
/*!40000 ALTER TABLE `menu_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `network_adapter`
--

DROP TABLE IF EXISTS `network_adapter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `network_adapter` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `enable` tinyint(1) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `updateby` varchar(100) DEFAULT NULL,
  `updatetime` datetime DEFAULT NULL,
  `server_id` bigint(20) DEFAULT NULL,
  `mtu` bigint(20) NOT NULL DEFAULT '0',
  `hardwareaddr` varchar(64) NOT NULL DEFAULT '',
  `flags` varchar(32) NOT NULL DEFAULT '',
  `addrs` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `network_adapter`
--

LOCK TABLES `network_adapter` WRITE;
/*!40000 ALTER TABLE `network_adapter` DISABLE KEYS */;
INSERT INTO `network_adapter` VALUES (1,'lo0',0,NULL,'','','2017-04-11 16:18:53',1,16384,'','up,loopback,multicast','127.0.0.1/8,::1/128,fe80::1/64'),(2,'gif0',0,NULL,'','','2017-04-11 16:18:53',1,1280,'','pointtopoint,multicast',''),(3,'stf0',0,NULL,'','','2017-04-11 16:18:54',1,1280,'','',''),(4,'en1',0,NULL,'','','2017-04-11 16:18:54',1,1500,'9a:00:07:81:06:c0','up,broadcast',''),(5,'bridge0',0,NULL,'','','2017-04-11 16:18:54',1,1500,'9a:00:07:81:06:c0','broadcast,multicast',''),(6,'p2p0',0,NULL,'','','2017-04-11 16:18:54',1,2304,'0a:6d:41:bc:5b:34','up,broadcast,multicast',''),(7,'awdl0',0,NULL,'','','2017-04-11 16:18:54',1,1484,'b2:53:b0:68:f4:6c','up,broadcast,multicast','fe80::b053:b0ff:fe68:f46c/64'),(8,'utun0',0,NULL,'','','2017-04-11 16:18:54',1,2000,'','up,pointtopoint,multicast','fe80::6bab:177a:6e99:5983/64'),(9,'ppp0',0,NULL,'','','2017-04-11 16:18:54',1,1280,'','up,pointtopoint,multicast','10.1.1.18/24');
/*!40000 ALTER TABLE `network_adapter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `network_bandwidth`
--

DROP TABLE IF EXISTS `network_bandwidth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `network_bandwidth` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `max_bandwidth` double DEFAULT NULL,
  `min_bandwidth` double DEFAULT NULL,
  `min_cost` double DEFAULT NULL,
  `unit_cost` double DEFAULT NULL,
  `comment` varchar(255) NOT NULL DEFAULT '',
  `isp_id` bigint(20) NOT NULL,
  `state_id` bigint(20) NOT NULL,
  `room_id` bigint(20) DEFAULT NULL,
  `rack_id` bigint(20) DEFAULT NULL,
  `enable` tinyint(1) DEFAULT NULL,
  `createtime` datetime NOT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `updateby` varchar(100) DEFAULT NULL,
  `updatetime` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `network_bandwidth`
--

LOCK TABLES `network_bandwidth` WRITE;
/*!40000 ALTER TABLE `network_bandwidth` DISABLE KEYS */;
/*!40000 ALTER TABLE `network_bandwidth` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `network_bandwidth_state`
--

DROP TABLE IF EXISTS `network_bandwidth_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `network_bandwidth_state` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `state` varchar(255) DEFAULT NULL,
  `enable` tinyint(1) DEFAULT NULL,
  `createtime` datetime NOT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `updateby` varchar(100) DEFAULT NULL,
  `updatetime` datetime NOT NULL,
  `color` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `network_bandwidth_state`
--

LOCK TABLES `network_bandwidth_state` WRITE;
/*!40000 ALTER TABLE `network_bandwidth_state` DISABLE KEYS */;
/*!40000 ALTER TABLE `network_bandwidth_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `networkip`
--

DROP TABLE IF EXISTS `networkip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `networkip` (
  `networkipid` bigint(20) NOT NULL AUTO_INCREMENT,
  `ipaddress` varchar(255) DEFAULT NULL,
  `netmask` varchar(11) DEFAULT NULL,
  `type` varchar(11) DEFAULT NULL,
  `vlan` int(11) DEFAULT NULL,
  `comment` varchar(512) DEFAULT NULL,
  `app_id` bigint(20) NOT NULL,
  `host_id` bigint(20) NOT NULL,
  `room_id` bigint(20) NOT NULL,
  `enable` tinyint(1) DEFAULT NULL,
  `createtime` datetime NOT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `updateby` varchar(100) DEFAULT NULL,
  `updatetime` datetime NOT NULL,
  PRIMARY KEY (`networkipid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `networkip`
--

LOCK TABLES `networkip` WRITE;
/*!40000 ALTER TABLE `networkip` DISABLE KEYS */;
/*!40000 ALTER TABLE `networkip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `networkiprange`
--

DROP TABLE IF EXISTS `networkiprange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `networkiprange` (
  `networkiprangeid` bigint(20) NOT NULL AUTO_INCREMENT,
  `ipaddress` varchar(255) DEFAULT NULL,
  `netmask` varchar(11) DEFAULT NULL,
  `startip` varchar(11) DEFAULT NULL,
  `endip` varchar(11) DEFAULT NULL,
  `vlan` varchar(256) DEFAULT NULL,
  `appid` bigint(20) DEFAULT NULL,
  `comment` varchar(512) DEFAULT NULL,
  `enable` tinyint(1) DEFAULT NULL,
  `createtime` datetime NOT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `updateby` varchar(100) DEFAULT NULL,
  `updatetime` datetime NOT NULL,
  PRIMARY KEY (`networkiprangeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `networkiprange`
--

LOCK TABLES `networkiprange` WRITE;
/*!40000 ALTER TABLE `networkiprange` DISABLE KEYS */;
/*!40000 ALTER TABLE `networkiprange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rack`
--

DROP TABLE IF EXISTS `rack`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rack` (
  `rackid` bigint(20) NOT NULL AUTO_INCREMENT,
  `rack_name` varchar(255) DEFAULT NULL,
  `standard_num` bigint(20) DEFAULT NULL,
  `top_not_available_num` bigint(20) DEFAULT NULL,
  `bottom_not_available_num` bigint(20) DEFAULT NULL,
  `avaliable_num` bigint(20) DEFAULT NULL,
  `tary_num` bigint(20) DEFAULT NULL,
  `rack_netflow` double DEFAULT NULL,
  `is_ups` int(11) DEFAULT NULL,
  `is_ab` int(11) DEFAULT NULL,
  `power` bigint(20) DEFAULT NULL,
  `comment` varchar(512) DEFAULT NULL,
  `state_id` bigint(20) NOT NULL,
  `room_id` bigint(20) NOT NULL,
  `enable` tinyint(1) DEFAULT NULL,
  `createtime` datetime NOT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `updateby` varchar(100) DEFAULT NULL,
  `updatetime` datetime NOT NULL,
  PRIMARY KEY (`rackid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rack`
--

LOCK TABLES `rack` WRITE;
/*!40000 ALTER TABLE `rack` DISABLE KEYS */;
/*!40000 ALTER TABLE `rack` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rack_state`
--

DROP TABLE IF EXISTS `rack_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rack_state` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `state` varchar(255) DEFAULT NULL,
  `enable` tinyint(1) DEFAULT NULL,
  `createtime` datetime NOT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `updateby` varchar(100) DEFAULT NULL,
  `updatetime` datetime NOT NULL,
  `color` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rack_state`
--

LOCK TABLES `rack_state` WRITE;
/*!40000 ALTER TABLE `rack_state` DISABLE KEYS */;
/*!40000 ALTER TABLE `rack_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `right`
--

DROP TABLE IF EXISTS `right`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `right` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `right_type` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `right`
--

LOCK TABLES `right` WRITE;
/*!40000 ALTER TABLE `right` DISABLE KEYS */;
/*!40000 ALTER TABLE `right` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `right_roles`
--

DROP TABLE IF EXISTS `right_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `right_roles` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `right_id` bigint(20) NOT NULL,
  `role_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `right_roles`
--

LOCK TABLES `right_roles` WRITE;
/*!40000 ALTER TABLE `right_roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `right_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `enable` tinyint(1) DEFAULT NULL,
  `createtime` datetime NOT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `updateby` varchar(100) DEFAULT NULL,
  `updatetime` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (8,'超级管理员',1,'2016-07-16 21:38:34','','','2016-11-25 10:24:52'),(9,'普通管理员',1,'2016-07-29 03:39:10','','','2017-05-09 14:52:57'),(11,'网络管理员',1,'2016-10-30 14:25:13','','','2017-05-09 14:52:20'),(12,'机房管理员',1,'2016-10-26 14:56:28','','','2016-11-25 16:43:59'),(13,'机柜管理员',1,'2016-11-18 03:55:13','','','2016-11-25 16:54:53');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `room`
--

DROP TABLE IF EXISTS `room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `room` (
  `roomid` bigint(20) NOT NULL AUTO_INCREMENT,
  `roomname` varchar(255) DEFAULT NULL,
  `floor` varchar(256) DEFAULT NULL,
  `roomno` varchar(256) DEFAULT NULL,
  `comment` varchar(512) DEFAULT NULL,
  `business_contact` varchar(256) DEFAULT NULL,
  `technical_contact` varchar(256) DEFAULT NULL,
  `receiving_contact` varchar(256) DEFAULT NULL,
  `maintenance_contact` varchar(256) DEFAULT NULL,
  `datacenter_id` bigint(20) NOT NULL,
  `state_id` bigint(20) NOT NULL,
  `enable` tinyint(1) DEFAULT NULL,
  `createtime` datetime NOT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `updateby` varchar(100) DEFAULT NULL,
  `updatetime` datetime NOT NULL,
  PRIMARY KEY (`roomid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room`
--

LOCK TABLES `room` WRITE;
/*!40000 ALTER TABLE `room` DISABLE KEYS */;
/*!40000 ALTER TABLE `room` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `room_state`
--

DROP TABLE IF EXISTS `room_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `room_state` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `state` varchar(255) NOT NULL DEFAULT '',
  `enable` tinyint(1) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `updateby` varchar(100) DEFAULT NULL,
  `updatetime` datetime DEFAULT NULL,
  `color` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room_state`
--

LOCK TABLES `room_state` WRITE;
/*!40000 ALTER TABLE `room_state` DISABLE KEYS */;
/*!40000 ALTER TABLE `room_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `server`
--

DROP TABLE IF EXISTS `server`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `server` (
  `serverid` bigint(20) NOT NULL AUTO_INCREMENT,
  `server_uuid` varchar(255) NOT NULL DEFAULT '',
  `sn` varchar(255) DEFAULT NULL,
  `modle` varchar(255) DEFAULT NULL,
  `isHpervisor` bigint(20) NOT NULL DEFAULT '0',
  `isServer` bigint(20) DEFAULT NULL,
  `ipaddress` varchar(512) NOT NULL DEFAULT '',
  `hostname` varchar(512) NOT NULL DEFAULT '',
  `comment` varchar(512) DEFAULT NULL,
  `rack_u_number` bigint(20) DEFAULT NULL,
  `manufacturer_id` bigint(20) DEFAULT NULL,
  `app_id` bigint(20) DEFAULT NULL,
  `rack_id` bigint(20) DEFAULT NULL,
  `host_id` bigint(20) NOT NULL,
  `supplier_id` bigint(20) DEFAULT NULL,
  `state_id` bigint(20) NOT NULL,
  `enable` tinyint(1) DEFAULT NULL,
  `createtime` datetime NOT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `updateby` varchar(100) DEFAULT NULL,
  `updatetime` datetime NOT NULL,
  PRIMARY KEY (`serverid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `server`
--

LOCK TABLES `server` WRITE;
/*!40000 ALTER TABLE `server` DISABLE KEYS */;
INSERT INTO `server` VALUES (1,'46be5c0f-7df8-4b4e-b742-c5258a7a14b8','','',0,0,'10.0.2.22','jenkins','',-1,NULL,NULL,NULL,2,NULL,1,0,'2017-05-02 01:33:04','','','2017-04-11 15:05:39'),(2,'24b93b5b-0b5f-49fa-a607-4584f7d45e8d','','',0,0,'10.0.2.90','vpn.dev.oneoaas.com','',-1,NULL,NULL,NULL,2,NULL,1,0,'2017-04-14 23:07:53','','','2017-04-17 14:48:45'),(3,'ed0fa736-7205-4ca3-851d-18f22a6ff910','','',0,0,'192.168.1.100','smtp.exmail.qq.com','',-1,NULL,NULL,NULL,1,NULL,1,0,'2017-04-18 14:02:07','','','2017-04-18 14:02:07');
/*!40000 ALTER TABLE `server` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `server_port`
--

DROP TABLE IF EXISTS `server_port`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `server_port` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ip` varchar(64) NOT NULL DEFAULT '',
  `port` int(10) unsigned NOT NULL DEFAULT '0',
  `proccess` varchar(128) NOT NULL DEFAULT '',
  `server_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=279 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `server_port`
--

LOCK TABLES `server_port` WRITE;
/*!40000 ALTER TABLE `server_port` DISABLE KEYS */;
INSERT INTO `server_port` VALUES (166,'*',62338,'SystemUIServer',1),(167,'*',5091,'UPEdit',1),(168,'10.1.1.18',56779,'Google Chrome',1),(169,'10.0.2.216',53125,'Google Chrome',1),(170,'10.1.1.18',56630,'Google Chrome',1),(171,'10.1.1.18',56760,'Google Chrome',1),(172,'10.0.2.216',54163,'Google Chrome',1),(173,'10.1.1.18',56798,'Google Chrome',1),(174,'10.1.1.18',56799,'Google Chrome',1),(175,'10.1.1.18',56801,'Google Chrome',1),(176,'10.1.1.18',56761,'Google Chrome',1),(177,'10.1.1.18',56762,'Google Chrome',1),(178,'10.1.1.18',56763,'Google Chrome',1),(179,'10.1.1.18',56764,'Google Chrome',1),(180,'10.1.1.18',56765,'Google Chrome',1),(181,'10.1.1.18',56800,'Google Chrome',1),(182,'10.0.2.216',56127,'Google Chrome',1),(183,'10.1.1.18',56802,'Google Chrome',1),(184,'10.1.1.18',56615,'Google Chrome',1),(185,'10.0.2.216',54188,'Google Chrome',1),(186,'10.1.1.18',56619,'Google Chrome',1),(187,'10.1.1.18',56793,'Google Chrome',1),(188,'10.1.1.18',56685,'Google Chrome',1),(189,'10.1.1.18',56732,'Google Chrome',1),(190,'10.0.2.216',56447,'Google Chrome',1),(191,'10.1.1.18',56733,'Google Chrome',1),(192,'10.1.1.18',56781,'Google Chrome',1),(193,'10.1.1.18',56631,'Google Chrome',1),(194,'10.1.1.18',56632,'Google Chrome',1),(195,'10.1.1.18',56693,'Google Chrome',1),(196,'10.1.1.18',56634,'Google Chrome',1),(197,'10.1.1.18',56789,'Google Chrome',1),(198,'10.1.1.18',56794,'Google Chrome',1),(199,'10.1.1.18',56738,'Google Chrome',1),(200,'10.0.2.216',56303,'Google Chrome',1),(201,'10.1.1.18',56739,'Google Chrome',1),(202,'10.1.1.18',56740,'Google Chrome',1),(203,'10.1.1.18',56741,'Google Chrome',1),(204,'10.1.1.18',56795,'Google Chrome',1),(205,'10.1.1.18',56661,'Google Chrome',1),(206,'10.1.1.18',56659,'Google Chrome',1),(207,'127.0.0.1',10001,'gogland',1),(208,'127.0.0.1',6942,'gogland',1),(209,'127.0.0.1',63342,'gogland',1),(210,'10.1.5.6',61489,'nwjs',1),(211,'10.0.2.216',61802,'nwjs',1),(212,'10.1.5.6',57931,'nwjs',1),(213,'10.0.2.216',62343,'nwjs',1),(214,'10.1.1.18',55911,'nwjs',1),(215,'10.1.1.18',57977,'nwjs',1),(216,'10.0.2.216',51303,'nwjs',1),(217,'*',57879,'com.docker.slirp',1),(218,'127.0.0.1',6943,'webstorm',1),(219,'127.0.0.1',63343,'webstorm',1),(221,'10.0.2.216',56497,'ssh',1),(222,'10.0.2.216',56810,'go run oneoaas-c',1),(223,'*',9898,'go run oneoaas-c',1),(224,'10.1.1.18',56833,'Google Chrome',1),(225,'10.1.1.18',56834,'Google Chrome',1),(226,'10.0.2.216',56841,'go run oneoaas-c',1),(227,'*',56755,'com.docker.slirp',1),(269,'::',7190,'tp_web',2),(270,'::',22,'sshd',2),(271,'::1',5432,'postmaster',2),(272,'0.0.0.0',8090,'python',2),(273,'0.0.0.0',52189,'tp_core',2),(274,'0.0.0.0',8000,'python',2),(275,'127.0.0.1',27017,'mongod',2),(276,'0.0.0.0',3306,'mysqld',2),(277,'0.0.0.0',8080,'alertad',2),(278,'0.0.0.0',52080,'tp_core',2);
/*!40000 ALTER TABLE `server_port` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `server_state`
--

DROP TABLE IF EXISTS `server_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `server_state` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `state` varchar(255) NOT NULL DEFAULT '',
  `enable` tinyint(1) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `updateby` varchar(100) DEFAULT NULL,
  `updatetime` datetime DEFAULT NULL,
  `color` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `server_state`
--

LOCK TABLES `server_state` WRITE;
/*!40000 ALTER TABLE `server_state` DISABLE KEYS */;
/*!40000 ALTER TABLE `server_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `session`
--

DROP TABLE IF EXISTS `session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `session` (
  `session_key` char(64) NOT NULL,
  `session_data` blob,
  `session_expiry` int(11) unsigned NOT NULL,
  PRIMARY KEY (`session_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `session`
--

LOCK TABLES `session` WRITE;
/*!40000 ALTER TABLE `session` DISABLE KEYS */;
INSERT INTO `session` VALUES ('358caa27838918e35dd915937e815771','����\0\0\0�\���\0string\n\0userinfo*models.User��User��\0\rUserid\0Name\0	LoginName\0Email\0ContactPhone\0Password\0Salt\0	LoginTime��\0RegisterTime��\0\nUpdateTime��\0LoginIp\0Role��\0Token��\0\0\0��Time��\0\0\0{��Role��\0	Id\0Name\0Enable\0\nCreateTime��\0CreateBy\0UpdateBy\0\nUpdateTime��\0User��\0Menu��\0\0\0��[]*models.User��\0��\0\0��[]*models.Menu��\0��\0\0������\0MenuId\0Name\0DisplayName\0Url\0ParentId\0Level\0Logo\0Class\0Enable\0\nCreateTime��\0CreateBy\0UpdateBy\0\nUpdateTime��\0Role��\0Active\0\0\0��[]*models.Role��\0��\0\0\"��[]*models.AccessKey��\0��\0\0������\0Id\0User��\0\rAccessKeyName\0\rAccessKeyType\0AccessKeyId\0AccessKeySecret\0\rAccessKeyDesc\0	IsDisable\0IsDelete\0\nExpireTime\0\nCreateTime��\0\0\0����\roneoaasoneoaassupport@oneoaas.com02160950835 89dde4c2297a343feecbfee2d9d590feQQoxl6n7`!@.[#V7\0\0\0Уs9�\0�\�\0\0\0\�6g\�\0\0\0\0\�\0\0\0Ф	P\0\0\0\0\�\n10.0.2.220超级管理员\0\0\0\�ؚ\0\0\0\0\�\0\0\0\�\�@�\0\0\0\0\�\0\0frontendself e6a3ee8552021a26009d2e5cce573e12��eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhZG1pbiI6dHJ1ZSwiZXhwIjoxNDk2MjgwNDM2LCJpYXQiOjE0OTM2ODg0MzYsInR5cGUiOiJzZWxmIiwidXNlcm5hbWUiOiJhZG1pbiJ9.yanrhLrDV6lYHDcRwZxeXVDSEMu9rlnvwpwl-lHQ910system auto generate��^\�\�\0\0\0К�4\0\0\0\0\�\0\0',1494318128);
/*!40000 ALTER TABLE `session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `software`
--

DROP TABLE IF EXISTS `software`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `software` (
  `softwareid` bigint(20) NOT NULL AUTO_INCREMENT,
  `software` varchar(255) DEFAULT NULL,
  `version` varchar(512) DEFAULT NULL,
  `appid` bigint(20) DEFAULT NULL,
  `comment` varchar(512) DEFAULT NULL,
  `enable` tinyint(1) DEFAULT NULL,
  `createtime` datetime NOT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `updateby` varchar(100) DEFAULT NULL,
  `updatetime` datetime NOT NULL,
  PRIMARY KEY (`softwareid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `software`
--

LOCK TABLES `software` WRITE;
/*!40000 ALTER TABLE `software` DISABLE KEYS */;
/*!40000 ALTER TABLE `software` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier`
--

DROP TABLE IF EXISTS `supplier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supplier` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `supplier` varchar(255) DEFAULT NULL,
  `business_contact` varchar(32) DEFAULT NULL,
  `business_tel_phone` varchar(32) DEFAULT NULL,
  `business_mobile_phone` varchar(32) DEFAULT NULL,
  `business_email` varchar(32) DEFAULT NULL,
  `technology_contact` varchar(32) DEFAULT NULL,
  `technology_telphone` varchar(32) DEFAULT NULL,
  `technology_mobile_phone` varchar(32) DEFAULT NULL,
  `technology_email` varchar(32) DEFAULT NULL,
  `office_address` varchar(32) DEFAULT NULL,
  `comment` varchar(512) DEFAULT NULL,
  `enable` tinyint(1) DEFAULT NULL,
  `createtime` datetime NOT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `updateby` varchar(100) DEFAULT NULL,
  `updatetime` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier`
--

LOCK TABLES `supplier` WRITE;
/*!40000 ALTER TABLE `supplier` DISABLE KEYS */;
/*!40000 ALTER TABLE `supplier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_color`
--

DROP TABLE IF EXISTS `system_color`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_color` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `color` varchar(100) NOT NULL DEFAULT '',
  `description` varchar(100) DEFAULT NULL,
  `enable` tinyint(1) NOT NULL DEFAULT '0',
  `createtime` datetime NOT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `updateby` varchar(100) DEFAULT NULL,
  `updatetime` datetime NOT NULL,
  `type` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_color`
--

LOCK TABLES `system_color` WRITE;
/*!40000 ALTER TABLE `system_color` DISABLE KEYS */;
INSERT INTO `system_color` VALUES (1,'#FFC85F','橙色',0,'2016-12-20 16:09:49','admin','admin','2016-12-20 16:09:49','state'),(2,'#FF8B51','红橙色',0,'2016-12-20 16:09:49','admin','admin','2016-12-20 16:09:49','state'),(3,'#6BC86F','淡绿色',0,'2016-12-20 16:09:49','admin','admin','2016-12-20 16:09:49','state'),(4,'#0DB550','深绿色',0,'2016-12-20 16:09:49','admin','admin','2016-12-20 16:09:49','state'),(5,'#7EA2AB','灰色',0,'2016-12-20 16:09:49','admin','admin','2016-12-20 16:09:49','state'),(6,'#317F9E','深蓝色',0,'2016-12-20 16:09:49','admin','admin','2016-12-20 16:09:49','state');
/*!40000 ALTER TABLE `system_color` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_email`
--

DROP TABLE IF EXISTS `system_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_email` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `account` varchar(50) NOT NULL DEFAULT '',
  `password` varchar(20) NOT NULL DEFAULT '',
  `port` varchar(10) NOT NULL DEFAULT '',
  `server` varchar(20) NOT NULL DEFAULT '',
  `create_time` datetime NOT NULL,
  `create_by` varchar(100) DEFAULT NULL,
  `update_by` varchar(100) DEFAULT NULL,
  `update_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_email`
--

LOCK TABLES `system_email` WRITE;
/*!40000 ALTER TABLE `system_email` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_log`
--

DROP TABLE IF EXISTS `system_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL,
  `user_name` varchar(20) NOT NULL DEFAULT '',
  `module_name` varchar(20) NOT NULL DEFAULT '',
  `module_display_name` varchar(20) NOT NULL DEFAULT '',
  `entity_name` varchar(20) NOT NULL DEFAULT '',
  `entity_display_name` varchar(20) NOT NULL DEFAULT '',
  `instance_id` varchar(20) NOT NULL DEFAULT '',
  `instance_display_name` varchar(20) NOT NULL DEFAULT '',
  `operation` varchar(20) NOT NULL DEFAULT '',
  `cause` varchar(100) NOT NULL DEFAULT '',
  `create_time` datetime NOT NULL,
  `create_by` varchar(100) DEFAULT NULL,
  `update_by` varchar(100) DEFAULT NULL,
  `update_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_log`
--

LOCK TABLES `system_log` WRITE;
/*!40000 ALTER TABLE `system_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `userid` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `login_name` varchar(45) DEFAULT NULL,
  `email` varchar(128) NOT NULL DEFAULT '',
  `contact_phone` varchar(32) NOT NULL DEFAULT '',
  `password` varchar(32) NOT NULL DEFAULT '',
  `salt` varchar(32) NOT NULL DEFAULT '',
  `role_id` bigint(20) NOT NULL,
  `login_time` datetime DEFAULT NULL,
  `register_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `login_ip` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`userid`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `contact_phone` (`contact_phone`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'oneoaas','oneoaas','support@oneoaas.com','02160950835','89dde4c2297a343feecbfee2d9d590fe','QQoxl6n7`!@.[#V7',8,'2017-05-09 16:21:50','2017-08-29 03:36:51','2017-05-10 03:02:40','10.0.2.220');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_roles`
--

DROP TABLE IF EXISTS `user_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_roles` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `role_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=126 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_roles`
--

LOCK TABLES `user_roles` WRITE;
/*!40000 ALTER TABLE `user_roles` DISABLE KEYS */;
INSERT INTO `user_roles` VALUES (4,9,9),(6,0,12),(8,13,9),(9,0,0),(10,0,14),(11,0,14),(14,18,14),(15,0,13),(16,0,13),(17,0,13),(19,0,13),(21,0,11),(23,0,12),(24,0,9),(25,0,9),(26,0,12),(27,0,12),(28,0,9),(29,0,0),(30,0,0),(31,0,9),(32,0,0),(33,0,0),(34,0,9),(35,0,9),(36,0,9),(37,0,9),(38,0,9),(39,0,9),(40,0,9),(41,0,9),(42,0,9),(43,0,9),(44,0,9),(45,0,9),(46,0,9),(47,0,9),(48,0,9),(49,0,9),(50,0,9),(51,0,9),(52,0,9),(53,0,9),(54,0,9),(55,0,9),(56,0,9),(57,0,9),(59,0,9),(60,0,9),(61,0,9),(62,0,9),(63,0,9),(64,0,9),(65,0,9),(66,0,9),(67,0,9),(68,0,9),(74,0,0),(75,0,0),(76,0,0),(77,0,0),(78,0,0),(79,0,0),(80,0,0),(81,0,0),(82,46,16),(83,0,16),(84,0,16),(85,0,16),(86,49,16),(87,0,9),(88,0,9),(89,50,9),(90,0,8),(91,0,8),(92,0,9),(93,0,8),(94,0,8),(95,0,8),(96,0,8),(97,0,8),(98,0,8),(99,21,8),(101,0,8),(102,0,9),(103,0,8),(104,0,8),(106,0,8),(107,0,8),(108,0,8),(112,0,9),(117,0,11),(118,0,9),(119,0,11),(120,0,8),(121,0,8),(123,0,9),(124,30,9);
/*!40000 ALTER TABLE `user_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `virt`
--

DROP TABLE IF EXISTS `virt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `virt` (
  `virtid` bigint(20) NOT NULL AUTO_INCREMENT,
  `sn` varchar(255) DEFAULT NULL,
  `virttypeid` int(11) NOT NULL DEFAULT '0',
  `cpu` varchar(256) NOT NULL DEFAULT '',
  `memory` varchar(256) NOT NULL DEFAULT '',
  `harddisk` varchar(256) NOT NULL DEFAULT '',
  `networkcard` varchar(256) NOT NULL DEFAULT '',
  `ishypervisor` varchar(256) NOT NULL DEFAULT '',
  `hostname` varchar(256) NOT NULL DEFAULT '',
  `appid` varchar(256) NOT NULL DEFAULT '',
  `comment` varchar(512) DEFAULT NULL,
  `enable` tinyint(1) DEFAULT NULL,
  `createtime` datetime NOT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `updateby` varchar(100) DEFAULT NULL,
  `updatetime` datetime NOT NULL,
  PRIMARY KEY (`virtid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `virt`
--

LOCK TABLES `virt` WRITE;
/*!40000 ALTER TABLE `virt` DISABLE KEYS */;
/*!40000 ALTER TABLE `virt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `virttype`
--

DROP TABLE IF EXISTS `virttype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `virttype` (
  `virttypeid` int(11) NOT NULL AUTO_INCREMENT,
  `virttype` varchar(255) NOT NULL DEFAULT '',
  `comment` varchar(512) DEFAULT NULL,
  `enable` tinyint(1) DEFAULT NULL,
  `createtime` datetime NOT NULL,
  `createby` varchar(100) DEFAULT NULL,
  `updateby` varchar(100) DEFAULT NULL,
  `updatetime` datetime NOT NULL,
  PRIMARY KEY (`virttypeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `virttype`
--

LOCK TABLES `virttype` WRITE;
/*!40000 ALTER TABLE `virttype` DISABLE KEYS */;
/*!40000 ALTER TABLE `virttype` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-05-09  4:42:24
