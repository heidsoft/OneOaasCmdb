require('./bootstrap-table-angular');
module.exports = 'bsTable';