#!/bin/bash
#cmdb 启动脚本
nohup $(pwd)/oneoaas-cmdb &
